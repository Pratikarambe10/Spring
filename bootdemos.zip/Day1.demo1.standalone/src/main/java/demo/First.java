package demo;

import org.springframework.stereotype.Component;

@Component
public class First {
	public First(){
		System.out.println("in First Constructor ...");
	}
	public void mymethod(){
		System.out.println("in mymethod of first ...");
	}
}
