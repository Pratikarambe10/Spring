
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;

import demo.First;
@SpringBootApplication(scanBasePackages="demo")
public class Application {
	public static void main(String[] args) {
		System.out.println("in main before run ");
	ConfigurableApplicationContext ctx  = 	SpringApplication.run(Application.class, args);
	First f1 = ctx.getBean("m1",First.class);
	f1.mymethod();
	First f2 = ctx.getBean("m1",First.class);
	f2.mymethod();
	First f3 = ctx.getBean("m1",First.class);
	f3.mymethod();
		System.out.println("in main after run");
	}
	
	@Bean
	@Scope(value="prototype")
	public First m1(){
		System.out.println(" in m1.....");
		return new First();
	}
}
