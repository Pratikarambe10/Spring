import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import model.Dept;
import repo.DeptRepository;

@SpringBootApplication(scanBasePackages="cons")
@EnableJpaRepositories(basePackages="repo")
@EntityScan(basePackages="model")
public class Application {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = SpringApplication.run(Application.class, args);

	}
	
	
	@Bean
	public String m1(DeptRepository repo){
		System.out.println(repo);
		for(int i = 10; i< 100;i+=10)
		{
			Dept d= new Dept();
			d.setDeptno(i);
			d.setDname("Nameof"+i);
			d.setLoc("Pune");
			repo.save(d);
		}
		
		return "s";
	}

}
