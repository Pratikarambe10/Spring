package cons;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class BaseController {
	
	@GetMapping(value="/")
	public ModelAndView simple(){
		return new ModelAndView("/index.jsp");
	}
}
