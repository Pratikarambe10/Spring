package cons;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import model.Dept;
import repo.DeptRepository;

@RestController
public class InsertController {
	@Autowired
	private DeptRepository repo;
	
	@GetMapping(value="/insert")
	public ModelAndView insertget(){
		System.out.println("in insert get");
		return new ModelAndView( "/insert1.html");
	}
	
	@PostMapping(value="/insertp")
	public ModelAndView insertpost(Dept dept){
		System.out.println("in insert");
		repo.save(dept);
		return  new ModelAndView( "/index.jsp");
	}
}
