package cons;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import model.Dept;
import repo.DeptRepository;

@RestController
public class ListController {
	@Autowired
	private DeptRepository repo;
	
	@GetMapping(value="/listjson", produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Dept> listjson(){
		System.out.println("in list");
		
		return (List<Dept>)repo.findAll();
		
	}
	@GetMapping(value="/list")
	public String list(){
		System.out.println("in list");
		String str = "<html><table bgcolor='yellow' border='1'>";
		 List<Dept> list = (List<Dept>)repo.findAll();
		for (Dept dept : list) {
			str+="<tr>" + "<td>" +dept.getDeptno() + "</td>";
			str+="<td>" +dept.getDname() + "</td>";
			str+="<td>" +dept.getLoc() + "</td>" + "</tr>";
			
		}
		str+="</table></html>";
		return str;
	}

	
}
