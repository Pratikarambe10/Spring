import java.util.Date;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.PropertySource;

@SpringBootApplication(scanBasePackages="demo")
@PropertySource(value={"app.properties"})
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	/*	for(int i = 0; i<400;i++){
			System.out.println(i + " " + new Date());
			if(( i % 100)==0)
				System.err.println(i + "error "+ new Date());
		}*/
	}

}
