package demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class SimpleController {
	@Value(value="${demo.name}" )
	private String name;
	
	@Value(value="${demo.addr}" )
	private String addr;
	
	
	@GetMapping(value="/")
	public String simple(){
		return "<html><h1>Simple Spring Boot  </h1><h1>Name : " + name+"  </h1><h1>Address : "+ addr+"</h1></html>";
	}
}


