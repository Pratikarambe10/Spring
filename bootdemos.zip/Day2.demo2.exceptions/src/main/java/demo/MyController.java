package demo;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;

import org.springframework.boot.autoconfigure.web.ErrorController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController

public class MyController implements ErrorController {
	
	private static final String errorpath="/error";
	@GetMapping(errorpath)
	public String base1(HttpServletRequest req){
		Object status = req.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
		Object str = req.getAttribute(RequestDispatcher.ERROR_EXCEPTION );
		 				
		System.out.println("status =" + status);
		System.out.println("ex details  =" + str.toString());
		return "<h1>Some Error</h1> ";
	}
	

	public String getErrorPath() {
		System.out.println("in getError path ...");
		return errorpath;
	}
	
	
	@GetMapping("/")
	public ModelAndView base(){
		return new ModelAndView("/index.html");
	}
	@GetMapping(value="/add")
	public String add(@RequestParam(name="n1")int n1,@RequestParam(name="n2") int n2){
		return "<h1>Sum = " + (n1+n2) + "</h1><a href='/'>Back</a></h1>";
	}

	@GetMapping(value="/divide")
	public String add(@RequestParam(name="n1")String n1,@RequestParam(name="n2") String n2){
		int no1=0, no2=0;
		try{
			no1 = Integer.parseInt(n1);
			no2 = Integer.parseInt(n2);
			int result = no1/no2;
			return "<h1>Division  = " + result + "</h1><a href='/'>Back</a></h1>";	
		}finally{
			System.out.println("in finally");
		}
	}


}
